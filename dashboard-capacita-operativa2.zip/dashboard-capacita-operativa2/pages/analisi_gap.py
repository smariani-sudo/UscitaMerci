"""
Pagina dedicata all'analisi avanzata dei gap capacità/fabbisogno
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Aggiungi il path per importare i moduli utils
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.data_manager import DataManager
from utils.calculations import CalcolatoreCapacita

def show_advanced_gap_analysis():
    """Mostra analisi gap avanzata"""
    
    # Inizializzazione session state
    if 'data_manager' not in st.session_state:
        st.session_state.data_manager = DataManager()
    if 'calcolatore' not in st.session_state:
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    st.header("📊 Analisi Gap Avanzata")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    
    if not all([piano, capacita, config_operatori]):
        st.warning("⚠️ Configurare tutti i parametri prima di procedere con l'analisi")
        return
    
    tab1, tab2, tab3, tab4 = st.tabs([
        "Analisi Multi-dimensionale",
        "Previsioni Trend", 
        "Ottimizzazione Risorse",
        "Scenari What-If"
    ])
    
    with tab1:
        show_multidimensional_analysis(piano, capacita, config_operatori)
    
    with tab2:
        show_trend_forecast(piano, capacita, config_operatori)
    
    with tab3:
        show_resource_optimization(piano, capacita, config_operatori)
    
    with tab4:
        show_what_if_scenarios(piano, capacita, config_operatori)

def show_multidimensional_analysis(piano, capacita, config_operatori):
    """Analisi multi-dimensionale dei gap"""
    
    st.subheader("🎯 Analisi Multi-dimensionale")
    
    # Ordine corretto dei giorni e delle fasi (usato in tutti i grafici)
    ordine_giorni = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica']
    ordine_fasi = ['Scarico Mezzi', 'Controllo', 'Stoccaggio']
    
    # Calcolo metriche per tutti i giorni
    risultati_completi = {}
    
    categorie = st.session_state.data_manager.get_categorie()
    
    for giorno, dati_giorno in piano.items():
        risultati_completi[giorno] = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
            dati_giorno, capacita, config_operatori, categorie
        )
    
    # Heatmap gap per fase e giorno
    st.write("**🔥 Heatmap Intensità Gap:**")
    
    df_gap_heatmap = pd.DataFrame({
        giorno: {
            'Scarico Mezzi': risultati['gap_teste']['Scarico Mezzi'],
            'Controllo': risultati['gap_teste']['Controllo'],
            'Stoccaggio': risultati['gap_teste']['Stoccaggio']
        }
        for giorno, risultati in risultati_completi.items()
    }).T
    
    # Riordina righe e colonne
    df_gap_heatmap = df_gap_heatmap.reindex(index=ordine_giorni, columns=ordine_fasi)
    
    fig_heatmap = px.imshow(
        df_gap_heatmap.values,
        labels=dict(x="Fase", y="Giorno", color="Gap Operatori"),
        x=df_gap_heatmap.columns,
        y=df_gap_heatmap.index,
        color_continuous_scale='RdYlGn_r',
        title="Intensità Gap per Giorno e Fase",
        aspect='auto'
    )
    # Inverte l'asse Y per mostrare Lunedì in alto
    fig_heatmap.update_yaxes(autorange='reversed')
    
    st.plotly_chart(fig_heatmap, use_container_width=True)
    
    # Analisi utilizzo capacità
    st.write("**⚡ Analisi Utilizzo Capacità:**")
    
    utilizzi = {}
    for giorno, dati_giorno in piano.items():
        utilizzi[giorno] = st.session_state.calcolatore.calcola_utilizzo_capacita(
            dati_giorno, capacita, config_operatori, categorie
        )
    
    df_utilizzo = pd.DataFrame(utilizzi).T
    # Riordina i giorni
    df_utilizzo = df_utilizzo.reindex(ordine_giorni)
    
    fig_utilizzo = px.bar(
        df_utilizzo.reset_index().melt(id_vars='index', var_name='Fase', value_name='Utilizzo %'),
        x='index',
        y='Utilizzo %',
        color='Fase',
        barmode='group',
        title="Percentuale Utilizzo Capacità per Fase",
        labels={'index': 'Giorno'},
        category_orders={'index': ordine_giorni, 'Fase': ordine_fasi}
    )
    
    fig_utilizzo.add_hline(y=100, line_dash="dash", line_color="red", annotation_text="Soglia Max Capacità")
    fig_utilizzo.add_hline(y=80, line_dash="dash", line_color="orange", annotation_text="Soglia Ottimale")
    
    st.plotly_chart(fig_utilizzo, use_container_width=True)
    
    # Matrice correlazioni
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**📈 Statistiche Gap:**")
        
        stats_gap = df_gap_heatmap.describe()
        st.dataframe(stats_gap.round(2))
    
    with col2:
        st.write("**⚡ Statistiche Utilizzo:**")
        
        stats_utilizzo = df_utilizzo.describe()
        st.dataframe(stats_utilizzo.round(2))

def show_trend_forecast(piano, capacita, config_operatori):
    """Previsioni e trend analysis"""
    
    st.subheader("📈 Previsioni Trend")
    
    # Ottieni categorie dinamiche
    categorie = st.session_state.data_manager.get_categorie()
    
    # Simulazione trend storico (per demo)
    giorni_settimana = list(piano.keys())
    
    # Genera dati trend simulati
    np.random.seed(42)
    settimane_simulate = 8
    
    trend_data = []
    
    for settimana in range(1, settimane_simulate + 1):
        for i, giorno in enumerate(giorni_settimana):
            # Simula variazioni stagionali
            variazione = np.random.normal(1, 0.15)
            trend_factor = 1 + (settimana - 4) * 0.05  # Trend crescente
            
            for categoria in categorie:
                valore_base = piano[giorno].get(categoria, 0)
                valore_trend = valore_base * variazione * trend_factor
                
                trend_data.append({
                    'Settimana': settimana,
                    'Giorno': giorno,
                    'Categoria': categoria,
                    'CLP': max(0, valore_trend),
                    'Data': datetime.now() - timedelta(weeks=settimane_simulate-settimana, days=6-i)
                })
    
    df_trend = pd.DataFrame(trend_data)
    
    # Grafico trend per categoria
    fig_trend = px.line(
        df_trend.groupby(['Data', 'Categoria'])['CLP'].sum().reset_index(),
        x='Data',
        y='CLP',
        color='Categoria',
        title="Trend Storico CLP per Categoria",
        markers=True
    )
    
    st.plotly_chart(fig_trend, use_container_width=True)
    
    # Previsione gap futuro
    st.write("**🔮 Previsioni Gap Futuro:**")
    
    # Calcola gap per trend simulato
    gap_trend = []
    
    for _, row in df_trend.iterrows():
        # Converte sempre in datetime usando pandas
        try:
            row_date = pd.to_datetime(row['Data']).date()
        except (ValueError, TypeError):
            row_date = datetime.now().date()
        
        if row_date >= datetime.now().date():
            # Calcola solo per date future
            clp_giorno_sim = df_trend[
                (df_trend['Data'] == row['Data'])
            ].groupby('Categoria')['CLP'].sum().to_dict()
            
            risultati_sim = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                clp_giorno_sim, capacita, config_operatori, categorie
            )
            
            for fase in ['Scarico Mezzi', 'Controllo', 'Stoccaggio']:
                gap_trend.append({
                    'Data': row['Data'],
                    'Fase': fase,
                    'Gap': risultati_sim['gap_teste'][fase]
                })
    
    if gap_trend:
        df_gap_trend = pd.DataFrame(gap_trend).drop_duplicates()
        
        fig_gap_trend = px.line(
            df_gap_trend,
            x='Data',
            y='Gap',
            color='Fase',
            title="Previsione Gap Operatori",
            markers=True
        )
        
        fig_gap_trend.add_hline(y=0, line_dash="dash", line_color="black")
        st.plotly_chart(fig_gap_trend, use_container_width=True)
    
    # Alert previsioni
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**⚠️ Alert Trend:**")
        if df_trend['CLP'].mean() > sum(piano[g][c] for g in piano for c in piano[g]) / len(piano) * 1.1:
            st.warning("• Trend CLP in crescita (+10%)")
        else:
            st.success("• Trend CLP stabile")
    
    with col2:
        st.write("**📊 Previsione Prossima Settimana:**")
        prossima_settimana = df_trend['CLP'].tail(len(giorni_settimana) * 3).mean()
        settimana_corrente = sum(piano[g][c] for g in piano for c in piano[g]) / 3
        
        delta = ((prossima_settimana - settimana_corrente) / settimana_corrente) * 100
        st.metric("CLP Medio Previsto", f"{prossima_settimana:.0f}", f"{delta:+.1f}%")

def show_resource_optimization(piano, capacita, config_operatori):
    """Ottimizzazione risorse"""
    
    st.subheader("⚡ Ottimizzazione Risorse")
    
    # Ottimizzazione distribuzione operatori
    suggerimenti = st.session_state.calcolatore.ottimizza_distribuzione_operatori(
        piano, capacita
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**🎯 Configurazione Attuale:**")
        
        config_attuale = {
            'Scarico Mezzi': config_operatori.get('scarico_per_baia', 1) * 5,
            'Controllo': config_operatori.get('controllo_per_baia', 2) * 5,
            'Stoccaggio': config_operatori.get('stoccaggio_per_baia', 1) * 5
        }
        
        for fase, operatori in config_attuale.items():
            st.info(f"**{fase}:** {operatori} operatori")
    
    with col2:
        st.write("**💡 Configurazione Ottimizzata:**")
        
        for fase, dati in suggerimenti.items():
            operatori_suggeriti = dati['operatori_suggeriti'] * 5  # Per 5 baie
            delta = operatori_suggeriti - config_attuale[fase]
            
            if delta > 0:
                st.error(f"**{fase}:** {operatori_suggeriti} (+{delta})")
            elif delta < 0:
                st.success(f"**{fase}:** {operatori_suggeriti} ({delta})")
            else:
                st.info(f"**{fase}:** {operatori_suggeriti} (ottimale)")
    
    # Analisi costi ottimizzazione
    st.write("**💰 Analisi Costi Ottimizzazione:**")
    
    costo_ora_operatore = st.number_input(
        "Costo orario operatore (€)",
        min_value=10.0,
        max_value=50.0,
        value=25.0,
        step=1.0
    )
    
    if st.button("💰 Calcola Impatto Economico"):
        
        costi_attuali = 0
        costi_ottimizzati = 0
        
        for fase, dati in suggerimenti.items():
            ore_turno = config_operatori.get(f"ore_{fase.lower().replace(' ', '_').replace('mezzi', '')}", 8)
            if fase == "Scarico Mezzi":
                ore_turno = config_operatori.get("ore_scarico", 8)
            
            # Costi attuali
            operatori_attuali = config_attuale[fase]
            costo_attuale = operatori_attuali * ore_turno * costo_ora_operatore * 5  # 5 giorni
            costi_attuali += costo_attuale
            
            # Costi ottimizzati  
            operatori_ottimizzati = dati['operatori_suggeriti'] * 5
            costo_ottimizzato = operatori_ottimizzati * ore_turno * costo_ora_operatore * 5
            costi_ottimizzati += costo_ottimizzato
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Costi Attuali", f"€{costi_attuali:,.0f}")
        
        with col2:
            st.metric("Costi Ottimizzati", f"€{costi_ottimizzati:,.0f}")
        
        with col3:
            risparmio = costi_attuali - costi_ottimizzati
            st.metric("Risparmio Settimanale", f"€{risparmio:+,.0f}")
        
        if risparmio > 0:
            st.success(f"💰 Risparmio annuale stimato: €{risparmio * 52:,.0f}")
        elif risparmio < 0:
            st.warning(f"⚠️ Costo aggiuntivo annuale: €{abs(risparmio) * 52:,.0f}")

def show_what_if_scenarios(piano, capacita, config_operatori):
    """Analisi scenari What-If"""
    
    st.subheader("🎲 Analisi Scenari What-If")
    
    # Ottieni categorie dinamiche
    categorie = st.session_state.data_manager.get_categorie()
    
    # Selezione ambito analisi
    st.write("**🎯 Ambito Analisi:**")
    col_ambito1, col_ambito2 = st.columns([1, 2])
    
    with col_ambito1:
        ambito_analisi = st.radio(
            "Analizza:",
            ["Piano Completo", "Singolo Giorno"],
            horizontal=True,
            help="Scegli se analizzare l'intera settimana o un giorno specifico"
        )
    
    with col_ambito2:
        giorno_selezionato = None
        if ambito_analisi == "Singolo Giorno":
            giorni_disponibili = list(piano.keys()) if piano else []
            if giorni_disponibili:
                giorno_selezionato = st.selectbox(
                    "Seleziona Giorno:",
                    giorni_disponibili,
                    help="Scegli il giorno specifico da analizzare"
                )
                st.info(f"📅 Analisi What-If per: **{giorno_selezionato}**")
            else:
                st.warning("⚠️ Nessun piano settimanale disponibile")
                return
    
    st.divider()
    
    # Scenari di variazione
    st.write("**📊 Simulazione Variazioni:**")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Variazioni Carico:**")
        
        variazione_carico = st.slider(
            "Variazione % carico totale",
            min_value=-50,
            max_value=100,
            value=0,
            step=5
        )
        
        # Slider dinamici per tutte le categorie
        variazioni_categorie = {}
        for categoria in categorie:
            variazioni_categorie[categoria] = st.slider(
                f"Variazione % {categoria.lower()}",
                min_value=-50,
                max_value=100,
                value=0,
                step=5,
                key=f"what_if_{categoria}"
            )
    
    with col2:
        st.write("**Variazioni Risorse:**")
        
        variazione_operatori_sm = st.slider(
            "Operatori Scarico Mezzi",
            min_value=1,
            max_value=10,
            value=config_operatori.get('scarico_per_baia', 1)
        )
        
        variazione_operatori_ctr = st.slider(
            "Operatori Controllo",
            min_value=1,
            max_value=10,
            value=config_operatori.get('controllo_per_baia', 2)
        )
        
        variazione_operatori_stk = st.slider(
            "Operatori Stoccaggio",
            min_value=1,
            max_value=10,
            value=config_operatori.get('stoccaggio_per_baia', 1)
        )
        
        ore_extra = st.slider(
            "Ore extra turno",
            min_value=0,
            max_value=4,
            value=0
        )
    
    # Applica scenario
    if st.button("🚀 Simula Scenario"):
        
        # Determina quali giorni analizzare
        if ambito_analisi == "Singolo Giorno":
            giorni_da_analizzare = {giorno_selezionato: piano[giorno_selezionato]} if giorno_selezionato else {}
        else:
            giorni_da_analizzare = piano
        
        # Piano modificato
        piano_modificato = {}
        
        for giorno, dati_giorno in giorni_da_analizzare.items():
            piano_modificato[giorno] = {}
            
            for categoria, valore in dati_giorno.items():
                # Applica variazione generale
                valore_mod = valore * (1 + variazione_carico / 100)
                
                # Applica variazioni specifiche per tutte le categorie dinamiche
                if categoria in variazioni_categorie:
                    valore_mod *= (1 + variazioni_categorie[categoria] / 100)
                
                piano_modificato[giorno][categoria] = max(0, valore_mod)
        
        # Configurazione modificata
        config_modificata = config_operatori.copy()
        config_modificata['scarico_per_baia'] = variazione_operatori_sm
        config_modificata['controllo_per_baia'] = variazione_operatori_ctr
        config_modificata['stoccaggio_per_baia'] = variazione_operatori_stk
        
        config_modificata['ore_scarico'] += ore_extra
        config_modificata['ore_controllo'] += ore_extra
        config_modificata['ore_stoccaggio'] += ore_extra
        
        # Calcola risultati scenario
        risultati_scenario = {}
        
        for giorno, dati_giorno in piano_modificato.items():
            risultati_scenario[giorno] = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_modificata, categorie
            )
        
        # Confronto risultati
        st.write("---")
        
        # Titolo dinamico basato sull'ambito
        if ambito_analisi == "Singolo Giorno":
            st.write(f"**📊 Risultati Scenario ({giorno_selezionato}):**")
        else:
            st.write("**📊 Risultati Scenario (Media Settimanale):**")
        
        # Gap medio per fase
        gap_medio_scenario = {}
        for fase in ['Scarico Mezzi', 'Controllo', 'Stoccaggio']:
            gaps = [risultati[fase] for risultati in [r['gap_teste'] for r in risultati_scenario.values()]]
            gap_medio_scenario[fase] = sum(gaps) / len(gaps)
        
        # Gap medio originale - analizza solo i giorni corrispondenti all'ambito
        risultati_originali = {}
        for giorno, dati_giorno in giorni_da_analizzare.items():
            risultati_originali[giorno] = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_operatori, categorie
            )
        
        gap_medio_originale = {}
        for fase in ['Scarico Mezzi', 'Controllo', 'Stoccaggio']:
            gaps = [risultati[fase] for risultati in [r['gap_teste'] for r in risultati_originali.values()]]
            gap_medio_originale[fase] = sum(gaps) / len(gaps)
        
        # Visualizza confronto
        col1, col2, col3 = st.columns(3)
        
        with col1:
            delta_sm = gap_medio_scenario['Scarico Mezzi'] - gap_medio_originale['Scarico Mezzi']
            st.metric(
                "Gap Scarico Mezzi",
                f"{gap_medio_scenario['Scarico Mezzi']:.2f}",
                f"{delta_sm:+.2f}"
            )
        
        with col2:
            delta_ctr = gap_medio_scenario['Controllo'] - gap_medio_originale['Controllo']
            st.metric(
                "Gap Controllo",
                f"{gap_medio_scenario['Controllo']:.2f}",
                f"{delta_ctr:+.2f}"
            )
        
        with col3:
            delta_stk = gap_medio_scenario['Stoccaggio'] - gap_medio_originale['Stoccaggio']
            st.metric(
                "Gap Stoccaggio",
                f"{gap_medio_scenario['Stoccaggio']:.2f}",
                f"{delta_stk:+.2f}"
            )
        
        # Grafico confronto
        df_confronto = pd.DataFrame({
            'Fase': ['Scarico Mezzi', 'Controllo', 'Stoccaggio'],
            'Gap Originale': [
                gap_medio_originale['Scarico Mezzi'],
                gap_medio_originale['Controllo'], 
                gap_medio_originale['Stoccaggio']
            ],
            'Gap Scenario': [
                gap_medio_scenario['Scarico Mezzi'],
                gap_medio_scenario['Controllo'],
                gap_medio_scenario['Stoccaggio']
            ]
        })
        
        # Titolo dinamico per il grafico
        if ambito_analisi == "Singolo Giorno":
            titolo_grafico = f"Confronto Gap: Originale vs Scenario ({giorno_selezionato})"
        else:
            titolo_grafico = "Confronto Gap: Originale vs Scenario (Media Settimanale)"
        
        fig_confronto = px.bar(
            df_confronto.melt(id_vars='Fase', var_name='Tipo', value_name='Gap'),
            x='Fase',
            y='Gap',
            color='Tipo',
            barmode='group',
            title=titolo_grafico
        )
        
        fig_confronto.add_hline(y=0, line_dash="dash", line_color="black")
        st.plotly_chart(fig_confronto, use_container_width=True)

if __name__ == "__main__":
    show_advanced_gap_analysis()
