"""
Modulo per calcoli di capacità e fabbisogno operatori
"""

class CalcolatoreCapacita:
    """Classe per calcoli relativi a capacità produttiva e fabbisogno operatori"""
    
    def __init__(self):
        pass
    
    def calcola_fabbisogno_giornaliero(self, clp_giornaliero, capacita_produttive, config_operatori, categorie=None):
        """
        Calcola il fabbisogno di ore e operatori per un giorno specifico
        
        Args:
            clp_giornaliero (dict): CLP per categoria {'Barre': 2600, 'Idrosanitari': 4500, 'Minuteria': 2000}
            capacita_produttive (dict): Capacità per fase e categoria in CLP/h
            config_operatori (dict): Configurazione operatori e turni
            categorie (list): Lista delle categorie merceologiche. Se None, usa valori di default
            
        Returns:
            dict: Risultati con fabbisogno ore, teste e gap
        """
        
        fasi = ["Scarico Mezzi", "Controllo", "Stoccaggio"]
        if categorie is None:
            categorie = ["Barre", "Idrosanitari", "Minuteria"]  # Fallback per compatibilità
        
        # Mapping nomi fasi per compatibilità
        fase_mapping = {
            "Scarico Mezzi": "scarico",
            "Controllo": "controllo", 
            "Stoccaggio": "stoccaggio"
        }
        
        risultati = {
            'fabbisogno_ore': {},
            'fabbisogno_teste': {},
            'operatori_disponibili': {},
            'gap_teste': {}
        }
        
        for fase in fasi:
            # Calcolo ore necessarie per categoria
            ore_necessarie_totali = 0
            
            for categoria in categorie:
                clp_categoria = clp_giornaliero.get(categoria, 0)
                capacita_oraria = capacita_produttive.get(fase, {}).get(categoria, 1)
                
                if capacita_oraria > 0:
                    ore_necessarie = clp_categoria / capacita_oraria
                    ore_necessarie_totali += ore_necessarie
            
            risultati['fabbisogno_ore'][fase] = ore_necessarie_totali
            
            # Calcolo teste necessarie
            fase_key = fase_mapping[fase]
            ore_per_turno = config_operatori.get(f'ore_{fase_key}', 8)
            teste_necessarie = ore_necessarie_totali / ore_per_turno if ore_per_turno > 0 else 0
            risultati['fabbisogno_teste'][fase] = teste_necessarie
            
            # Operatori disponibili (baie dinamiche per fase)
            operatori_per_baia = config_operatori.get(f'{fase_key}_per_baia', 1)
            numero_baie = config_operatori.get(f'baie_{fase_key}', 5)  # Numero baie specifico per fase
            operatori_disponibili = operatori_per_baia * numero_baie
            risultati['operatori_disponibili'][fase] = operatori_disponibili
            
            # Calcolo gap
            gap = teste_necessarie - operatori_disponibili
            risultati['gap_teste'][fase] = gap
        
        return risultati
    
    def calcola_utilizzo_capacita(self, clp_giornaliero, capacita_produttive, config_operatori, categorie=None):
        """
        Calcola la percentuale di utilizzo della capacità per fase
        
        Args:
            clp_giornaliero (dict): CLP per categoria
            capacita_produttive (dict): Capacità produttive per fase
            config_operatori (dict): Configurazione operatori
            categorie (list): Lista delle categorie merceologiche. Se None, usa valori di default
            
        Returns:
            dict: Percentuale utilizzo per fase
        """
        
        fasi = ["Scarico Mezzi", "Controllo", "Stoccaggio"]
        utilizzo = {}
        
        for fase in fasi:
            # Capacità totale disponibile
            fase_key = fase.lower().replace(' ', '_')
            if fase == "Scarico Mezzi":
                fase_key = "scarico"
            elif fase == "Controllo":
                fase_key = "controllo"
            elif fase == "Stoccaggio":
                fase_key = "stoccaggio"
            
            operatori_disponibili = config_operatori.get(f'{fase_key}_per_baia', 1) * config_operatori.get(f'baie_{fase_key}', 5)
            ore_turno = config_operatori.get(f'ore_{fase_key}', 8)
            capacita_totale_ore = operatori_disponibili * ore_turno
            
            # Ore necessarie
            ore_necessarie = 0
            if categorie is None:
                categorie = ["Barre", "Idrosanitari", "Minuteria"]  # Fallback per compatibilità
            for categoria in categorie:
                clp_categoria = clp_giornaliero.get(categoria, 0)
                capacita_oraria = capacita_produttive.get(fase, {}).get(categoria, 1)
                if capacita_oraria > 0:
                    ore_necessarie += clp_categoria / capacita_oraria
            
            # Percentuale utilizzo
            if capacita_totale_ore > 0:
                utilizzo[fase] = (ore_necessarie / capacita_totale_ore) * 100
            else:
                utilizzo[fase] = 0
        
        return utilizzo
    
    def ottimizza_distribuzione_operatori(self, clp_settimanale, capacita_produttive, categorie=None):
        """
        Suggerisce una distribuzione ottimale degli operatori basata sul carico settimanale
        
        Args:
            clp_settimanale (dict): CLP per giorno e categoria
            capacita_produttive (dict): Capacità produttive
            categorie (list): Lista delle categorie merceologiche. Se None, usa valori di default
            
        Returns:
            dict: Suggerimenti per ottimizzazione
        """
        
        # Calcolo carico medio per fase
        carichi_medi_fase = {"Scarico Mezzi": 0.0, "Controllo": 0.0, "Stoccaggio": 0.0}
        
        if categorie is None:
            categorie = ["Barre", "Idrosanitari", "Minuteria"]  # Fallback per compatibilità
        
        for giorno, dati_giorno in clp_settimanale.items():
            for fase in carichi_medi_fase.keys():
                carico_fase = 0
                for categoria in categorie:
                    clp_categoria = dati_giorno.get(categoria, 0)
                    capacita_oraria = capacita_produttive.get(fase, {}).get(categoria, 1)
                    if capacita_oraria > 0:
                        carico_fase += clp_categoria / capacita_oraria
                
                carichi_medi_fase[fase] += carico_fase
        
        # Media settimanale
        num_giorni = len(clp_settimanale)
        for fase in carichi_medi_fase:
            carichi_medi_fase[fase] = carichi_medi_fase[fase] / (num_giorni if num_giorni > 0 else 1)
        
        # Suggerimenti
        suggerimenti = {}
        carico_totale = sum(carichi_medi_fase.values())
        
        for fase, carico in carichi_medi_fase.items():
            percentuale = (carico / carico_totale * 100) if carico_totale > 0 else 0
            suggerimenti[fase] = {
                'carico_medio_ore': round(carico, 2),
                'percentuale_carico': round(percentuale, 2),
                'operatori_suggeriti': max(1, round(carico / 8))  # Assumendo 8h per turno
            }
        
        return suggerimenti
