"""
Modulo per gestione dati e persistenza
"""

import json
import os
import streamlit as st
from datetime import datetime

class DataManager:
    """Classe per gestione dati dell'applicazione"""
    
    def __init__(self):
        self.data_dir = "data"
        self.ensure_data_directory()
    
    def ensure_data_directory(self):
        """Crea la directory data se non esiste"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    def get_piano_settimanale(self):
        """Recupera il piano settimanale salvato"""
        if 'piano_settimanale' in st.session_state:
            return st.session_state.piano_settimanale
        
        try:
            with open(f"{self.data_dir}/piano_settimanale.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                st.session_state.piano_settimanale = data
                return data
        except FileNotFoundError:
            return {}
    
    def save_piano_settimanale(self, piano):
        """Salva il piano settimanale"""
        st.session_state.piano_settimanale = piano
        
        try:
            with open(f"{self.data_dir}/piano_settimanale.json", "w", encoding='utf-8') as f:
                json.dump(piano, f, indent=2, ensure_ascii=False)
            
            # Salva anche nello storico
            self.save_to_historical(piano, "piano_settimanale")
        except Exception as e:
            st.error(f"Errore nel salvataggio: {e}")
    
    def azzera_piano_settimanale(self):
        """Azzera tutti i valori del piano settimanale"""
        giorni = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"]
        categorie = self.get_categorie()
        
        piano_vuoto = {}
        for giorno in giorni:
            piano_vuoto[giorno] = {}
            for categoria in categorie:
                piano_vuoto[giorno][categoria] = 0
        
        self.save_piano_settimanale(piano_vuoto)
        return piano_vuoto
    
    def get_categorie(self):
        """Recupera le categorie merceologiche"""
        if 'categorie_merceologiche' in st.session_state:
            return st.session_state.categorie_merceologiche
        
        try:
            with open(f"{self.data_dir}/categorie_merceologiche.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                st.session_state.categorie_merceologiche = data
                return data
        except FileNotFoundError:
            # Categorie di default esistenti + le nuove richieste
            default_categorie = ["Barre", "Idrosanitari", "Minuteria", "Container", "Serbatoi", "Pallet"]
            self.save_categorie(default_categorie)
            return default_categorie
    
    def save_categorie(self, categorie):
        """Salva le categorie merceologiche"""
        st.session_state.categorie_merceologiche = categorie
        
        try:
            with open(f"{self.data_dir}/categorie_merceologiche.json", "w", encoding='utf-8') as f:
                json.dump(categorie, f, indent=2, ensure_ascii=False)
        except Exception as e:
            st.error(f"Errore nel salvataggio categorie: {e}")
    
    def add_categoria(self, nuova_categoria):
        """Aggiunge una nuova categoria merceologica"""
        categorie = self.get_categorie()
        if nuova_categoria not in categorie:
            categorie.append(nuova_categoria)
            self.save_categorie(categorie)
            
            # Aggiorna le capacità produttive per includere la nuova categoria
            self._aggiorna_capacita_per_nuova_categoria(nuova_categoria)
            
            return True
        return False
    
    def remove_categoria(self, categoria_da_rimuovere):
        """Rimuove una categoria merceologica"""
        categorie = self.get_categorie()
        if categoria_da_rimuovere in categorie and len(categorie) > 1:  # Mantieni almeno una categoria
            categorie.remove(categoria_da_rimuovere)
            self.save_categorie(categorie)
            
            # Rimuovi la categoria dalle capacità produttive
            self._rimuovi_categoria_da_capacita(categoria_da_rimuovere)
            
            return True
        return False
    
    def _aggiorna_capacita_per_nuova_categoria(self, nuova_categoria):
        """Aggiunge valori di default per una nuova categoria nelle capacità"""
        capacita = self.get_capacita_produttive()
        
        # Valori di default per le nuove categorie
        valori_default = {
            "Container": {"Scarico Mezzi": 200, "Controllo": 120, "Stoccaggio": 800},
            "Serbatoi": {"Scarico Mezzi": 150, "Controllo": 80, "Stoccaggio": 600},
            "Pallet": {"Scarico Mezzi": 300, "Controllo": 180, "Stoccaggio": 1200}
        }
        
        default_categoria = valori_default.get(nuova_categoria, {
            "Scarico Mezzi": 200,
            "Controllo": 100, 
            "Stoccaggio": 800
        })
        
        for fase in ["Scarico Mezzi", "Controllo", "Stoccaggio"]:
            if fase not in capacita:
                capacita[fase] = {}
            capacita[fase][nuova_categoria] = default_categoria[fase]
        
        self.save_capacita_produttive(capacita)
    
    def _rimuovi_categoria_da_capacita(self, categoria):
        """Rimuove una categoria dalle capacità produttive"""
        capacita = self.get_capacita_produttive()
        
        for fase in ["Scarico Mezzi", "Controllo", "Stoccaggio"]:
            if fase in capacita and categoria in capacita[fase]:
                del capacita[fase][categoria]
        
        self.save_capacita_produttive(capacita)
    
    def get_capacita_produttive(self):
        """Recupera le capacità produttive"""
        if 'capacita_produttive' in st.session_state:
            return st.session_state.capacita_produttive
        
        try:
            with open(f"{self.data_dir}/capacita_produttive.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                st.session_state.capacita_produttive = data
                return data
        except FileNotFoundError:
            # Valori di default dal documento
            default_capacita = {
                "Scarico Mezzi": {
                    "Barre": 280,
                    "Idrosanitari": 250,
                    "Minuteria": 200
                },
                "Controllo": {
                    "Barre": 150,
                    "Idrosanitari": 100,
                    "Minuteria": 130
                },
                "Stoccaggio": {
                    "Barre": 1000,
                    "Idrosanitari": 150,
                    "Minuteria": 200
                }
            }
            self.save_capacita_produttive(default_capacita)
            return default_capacita
    
    def save_capacita_produttive(self, capacita):
        """Salva le capacità produttive"""
        st.session_state.capacita_produttive = capacita
        
        try:
            with open(f"{self.data_dir}/capacita_produttive.json", "w", encoding='utf-8') as f:
                json.dump(capacita, f, indent=2, ensure_ascii=False)
        except Exception as e:
            st.error(f"Errore nel salvataggio: {e}")
    
    def get_configurazione_operatori(self):
        """Recupera la configurazione operatori"""
        if 'configurazione_operatori' in st.session_state:
            return st.session_state.configurazione_operatori
        
        try:
            with open(f"{self.data_dir}/configurazione_operatori.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                st.session_state.configurazione_operatori = data
                return data
        except FileNotFoundError:
            # Configurazione di default dal documento
            default_config = {
                "scarico_per_baia": 1,
                "controllo_per_baia": 2,
                "stoccaggio_per_baia": 1,
                "baie_scarico": 5,
                "baie_controllo": 5,
                "baie_stoccaggio": 5,
                "ore_scarico": 8,
                "ore_controllo": 8,
                "ore_stoccaggio": 8,
                "numero_baie": 5  # Mantenuto per compatibilità
            }
            self.save_configurazione_operatori(default_config)
            return default_config
    
    def save_configurazione_operatori(self, config):
        """Salva la configurazione operatori"""
        st.session_state.configurazione_operatori = config
        
        try:
            with open(f"{self.data_dir}/configurazione_operatori.json", "w", encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            st.error(f"Errore nel salvataggio: {e}")
    
    def save_to_historical(self, data, data_type):
        """Salva i dati nello storico"""
        timestamp = datetime.now().isoformat()
        historical_entry = {
            "timestamp": timestamp,
            "type": data_type,
            "data": data
        }
        
        historical_file = f"{self.data_dir}/storico.json"
        
        try:
            # Carica storico esistente
            if os.path.exists(historical_file):
                with open(historical_file, "r", encoding='utf-8') as f:
                    storico = json.load(f)
            else:
                storico = []
            
            # Aggiungi nuovo entry
            storico.append(historical_entry)
            
            # Mantieni solo gli ultimi 50 record
            if len(storico) > 50:
                storico = storico[-50:]
            
            # Salva aggiornato
            with open(historical_file, "w", encoding='utf-8') as f:
                json.dump(storico, f, indent=2, ensure_ascii=False)
        
        except Exception as e:
            st.error(f"Errore nel salvataggio storico: {e}")
    
    def get_historical_data(self):
        """Recupera i dati storici"""
        try:
            with open(f"{self.data_dir}/storico.json", "r", encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return []
    
    def export_all_data(self):
        """Esporta tutti i dati in un singolo file"""
        all_data = {
            "export_timestamp": datetime.now().isoformat(),
            "piano_settimanale": self.get_piano_settimanale(),
            "capacita_produttive": self.get_capacita_produttive(),
            "configurazione_operatori": self.get_configurazione_operatori(),
            "storico": self.get_historical_data()
        }
        
        return json.dumps(all_data, indent=2, ensure_ascii=False)
    
    def import_data(self, json_data):
        """Importa dati da JSON"""
        try:
            data = json.loads(json_data)
            
            if "piano_settimanale" in data:
                self.save_piano_settimanale(data["piano_settimanale"])
            
            if "capacita_produttive" in data:
                self.save_capacita_produttive(data["capacita_produttive"])
            
            if "configurazione_operatori" in data:
                self.save_configurazione_operatori(data["configurazione_operatori"])
            
            return True
        except Exception as e:
            st.error(f"Errore nell'importazione: {e}")
            return False
    
    def reset_all_data(self):
        """Reset di tutti i dati"""
        files_to_remove = [
            f"{self.data_dir}/piano_settimanale.json",
            f"{self.data_dir}/capacita_produttive.json",
            f"{self.data_dir}/configurazione_operatori.json",
            f"{self.data_dir}/storico.json"
        ]
        
        for file_path in files_to_remove:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                st.error(f"Errore nella rimozione di {file_path}: {e}")
        
        # Pulisci session state
        for key in ['piano_settimanale', 'capacita_produttive', 'configurazione_operatori']:
            if key in st.session_state:
                del st.session_state[key]
