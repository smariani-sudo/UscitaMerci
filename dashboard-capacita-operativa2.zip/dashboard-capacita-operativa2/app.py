import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import os
from utils.calculations import CalcolatoreCapacita
from utils.data_manager import DataManager

import sys
sys.path.append(os.path.join(os.path.dirname(__file__), 'pages'))
from configurazione import show_advanced_configuration

# Configurazione pagina
st.set_page_config(
    page_title="Dashboard Gestione Capacità/Carico Operativo",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inizializzazione session state
if 'data_manager' not in st.session_state:
    st.session_state.data_manager = DataManager()
if 'calcolatore' not in st.session_state:
    st.session_state.calcolatore = CalcolatoreCapacita()
if 'user_profile' not in st.session_state:
    st.session_state.user_profile = None

def show_profile_selection():
    st.title("🏭 Dashboard Gestione Capacità/Carico Operativo")
    st.markdown("---")
    
    st.header("👤 Selezione Profilo Utente")
    st.write("Seleziona il profilo con cui vuoi accedere all'applicazione:")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.write("")
        st.write("")
        
        col_admin, col_user = st.columns(2)
        
        with col_admin:
            if st.button("🔑 ADMIN", use_container_width=True, type="primary"):
                st.session_state.user_profile = "admin"
                st.rerun()
            st.caption("Accesso completo a tutte le funzionalità")
            st.markdown("""
            **Permessi:**
            - ✅ Inserimento piano settimanale
            - ✅ Modifica configurazioni
            - ✅ Analisi avanzate
            - ✅ KPI e reportistica
            """)
        
        with col_user:
            if st.button("👤 USER", use_container_width=True, type="secondary"):
                st.session_state.user_profile = "user"
                st.rerun()
            st.caption("Accesso in sola lettura")
            st.markdown("""
            **Permessi:**
            - 👁️ Visualizzazione piani
            - 👁️ Analisi gap
            - 👁️ KPI e reportistica
            - ❌ Modifica configurazioni
            """)

def main():
    if st.session_state.user_profile is None:
        show_profile_selection()
        return
    
    st.title("🏭 Dashboard Gestione Capacità/Carico Operativo")
    
    profile_icon = "🔑" if st.session_state.user_profile == "admin" else "👤"
    profile_name = "ADMIN" if st.session_state.user_profile == "admin" else "USER"
    st.caption(f"{profile_icon} Profilo: **{profile_name}**")
    st.markdown("---")
    
    st.sidebar.title("📋 Navigazione")
    
    if st.session_state.user_profile == "admin":
        page_options = ["Dashboard Principale", "Configurazione", "Analisi Gap", "KPI e reportistica"]
    else:
        page_options = ["Dashboard Principale", "Analisi Gap", "KPI e reportistica"]
    
    page = st.sidebar.selectbox("Seleziona sezione:", page_options)
    
    st.sidebar.markdown("---")
    if st.sidebar.button("🔄 Cambia Profilo", use_container_width=True):
        st.session_state.user_profile = None
        st.rerun()
    
    if page == "Dashboard Principale":
        show_main_dashboard()
    elif page == "Configurazione":
        show_advanced_configuration()
    elif page == "Analisi Gap":
        show_gap_analysis()
    elif page == "KPI e reportistica":
        show_historical_report()

def show_main_dashboard():
    st.header("📊 Dashboard Principale - Piano Settimanale CLP")
    
    is_admin = st.session_state.user_profile == "admin"
    
    if is_admin:
        st.subheader("📥 Inserimento Piano Settimanale")
    else:
        st.info("👁️ **Modalità Visualizzazione** - Per modificare i dati, accedi come Admin")
        st.subheader("📋 Piano Settimanale Corrente")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        if is_admin:
            st.write("**Inserisci i valori CLP per ciascuna categoria merceologica:**")
        else:
            st.write("**Visualizzazione valori CLP per categoria merceologica:**")
        
        giorni = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"]
        categorie = st.session_state.data_manager.get_categorie()
        piano_settimanale = st.session_state.data_manager.get_piano_settimanale()
        
        if is_admin:
            with st.form("piano_settimanale_form"):
                data_input = {}
                
                for giorno in giorni:
                    st.write(f"**{giorno}**")
                    data_input[giorno] = {}
                    
                    max_cols_per_riga = 6
                    num_categorie = len(categorie)
                    
                    for start_idx in range(0, num_categorie, max_cols_per_riga):
                        end_idx = min(start_idx + max_cols_per_riga, num_categorie)
                        categorie_riga = categorie[start_idx:end_idx]
                        cols = st.columns(len(categorie_riga))
                        
                        for i, categoria in enumerate(categorie_riga):
                            with cols[i]:
                                default_value = piano_settimanale.get(giorno, {}).get(categoria, 0)
                                data_input[giorno][categoria] = st.number_input(
                                    f"CLP {categoria}",
                                    min_value=0,
                                    value=default_value,
                                    step=100,
                                    key=f"{giorno}_{categoria}"
                                )
                    st.write("")
                
                col1, col2 = st.columns([1, 1])
                
                with col1:
                    azzera = st.form_submit_button("🗑️ Azzera Tutti i Valori", type="secondary")
                
                with col2:
                    submitted = st.form_submit_button("💾 Salva Piano Settimanale", type="primary")
                
                if azzera:
                    if st.session_state.get('conferma_azzeramento', False):
                        st.session_state.data_manager.azzera_piano_settimanale()
                        st.success("✅ Piano settimanale azzerato con successo!")
                        st.session_state.conferma_azzeramento = False
                        st.rerun()
                    else:
                        st.session_state.conferma_azzeramento = True
                        st.warning("⚠️ Clicca nuovamente per confermare l'azzeramento di tutti i valori")
                        st.rerun()
                
                if submitted:
                    st.session_state.data_manager.save_piano_settimanale(data_input)
                    st.success("✅ Piano settimanale salvato con successo!")
                    st.session_state.conferma_azzeramento = False
                    st.rerun()
        else:
            for giorno in giorni:
                st.write(f"**{giorno}**")
                
                max_cols_per_riga = 6
                num_categorie = len(categorie)
                
                for start_idx in range(0, num_categorie, max_cols_per_riga):
                    end_idx = min(start_idx + max_cols_per_riga, num_categorie)
                    categorie_riga = categorie[start_idx:end_idx]
                    cols = st.columns(len(categorie_riga))
                    
                    for i, categoria in enumerate(categorie_riga):
                        with cols[i]:
                            value = piano_settimanale.get(giorno, {}).get(categoria, 0)
                            st.metric(label=categoria, value=f"{value:,} CLP")
                st.write("")
    
    with col2:
        st.write("**Legenda Formula CLP:**")
        st.info("**CLP = Q × V × P**\n\n"
                "• **Q** = Quantità\n"
                "• **V** = Volume\n"
                "• **P** = Peso\n\n"
                "Il CLP rappresenta il Carico di Lavoro Potenziale")
    
    # Visualizzazione dati correnti se disponibili
    piano_attuale = st.session_state.data_manager.get_piano_settimanale()
    if piano_attuale:
        st.subheader("📈 Visualizzazione Piano Corrente")
        
        # Conversione in DataFrame per visualizzazione
        df_piano = pd.DataFrame(piano_attuale).T
        df_piano.index.name = "Giorno"
        
        # Grafico a barre per categoria
        categorie_grafico = st.session_state.data_manager.get_categorie()
        fig_barre = px.bar(
            df_piano.reset_index(),
            x="Giorno",
            y=categorie_grafico,
            title="Distribuzione CLP Settimanale per Categoria",
            labels={"value": "CLP", "variable": "Categoria"}
        )
        fig_barre.update_layout(height=400)
        st.plotly_chart(fig_barre, use_container_width=True)
        
        # Tabella riepilogativa
        st.subheader("📋 Riepilogo Piano Settimanale")
        df_piano["Totale"] = df_piano.sum(axis=1)
        st.dataframe(df_piano, use_container_width=True)
        
        # Calcolo fabbisogno operatori
        st.subheader("👥 Analisi Fabbisogno Operatori")
        
        capacita = st.session_state.data_manager.get_capacita_produttive()
        config_operatori = st.session_state.data_manager.get_configurazione_operatori()
        
        if capacita and config_operatori:
            risultati_analisi = {}
            
            for giorno, dati_giorno in piano_attuale.items():
                risultati_analisi[giorno] = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                    dati_giorno, capacita, config_operatori, categorie
                )
            
            # Visualizzazione risultati per giorno selezionato
            giorno_selezionato = st.selectbox("Seleziona giorno per analisi dettagliata:", giorni)
            
            if giorno_selezionato in risultati_analisi:
                risultati = risultati_analisi[giorno_selezionato]
                
                col1, col2, col3 = st.columns(3)
                
                fasi = ["Scarico Mezzi", "Controllo", "Stoccaggio"]
                for i, fase in enumerate(fasi):
                    with [col1, col2, col3][i]:
                        st.metric(
                            f"**{fase}**",
                            f"{risultati['fabbisogno_ore'][fase]:.1f} ore",
                            f"{risultati['fabbisogno_teste'][fase]:.1f} teste"
                        )
                        
                        gap = risultati['gap_teste'][fase]
                        if gap > 0:
                            st.error(f"⚠️ Gap: +{gap:.1f} teste necessarie")
                        elif gap < 0:
                            st.success(f"✅ Surplus: {abs(gap):.1f} teste")
                        else:
                            st.info("✅ Capacità bilanciata")
        else:
            st.warning("⚠️ Configurare prima le capacità produttive e gli operatori nella sezione Configurazione")


def show_gap_analysis():
    st.header("📊 Analisi Gap Capacità/Fabbisogno")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    
    if not all([piano, capacita, config_operatori]):
        st.warning("⚠️ Configurare prima i dati nella Dashboard Principale e nella sezione Configurazione")
        return
    
    # Calcolo gap per tutta la settimana
    risultati_settimana = {}
    
    categorie = st.session_state.data_manager.get_categorie()
    for giorno, dati_giorno in piano.items():
        risultati_settimana[giorno] = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
            dati_giorno, capacita, config_operatori, categorie
        )
    
    # Visualizzazione gap settimanale
    st.subheader("📈 Gap Settimanale per Fase")
    
    # Preparazione dati per grafici
    df_gap = pd.DataFrame({
        giorno: {
            'Scarico Mezzi': risultati['gap_teste']['Scarico Mezzi'],
            'Controllo': risultati['gap_teste']['Controllo'],
            'Stoccaggio': risultati['gap_teste']['Stoccaggio']
        }
        for giorno, risultati in risultati_settimana.items()
    }).T
    
    # Grafico gap
    fig_gap = go.Figure()
    
    fasi = ['Scarico Mezzi', 'Controllo', 'Stoccaggio']
    colori = ['#ff6b6b', '#4ecdc4', '#45b7d1']
    
    for i, fase in enumerate(fasi):
        fig_gap.add_trace(go.Bar(
            name=fase,
            x=df_gap.index,
            y=df_gap[fase],
            marker_color=colori[i]
        ))
    
    fig_gap.add_hline(y=0, line_dash="dash", line_color="black", annotation_text="Soglia Equilibrio")
    fig_gap.update_layout(
        title="Gap Teste per Fase (Valori Positivi = Carenza, Negativi = Surplus)",
        xaxis_title="Giorno",
        yaxis_title="Gap Teste",
        barmode='group',
        height=500
    )
    
    st.plotly_chart(fig_gap, use_container_width=True)
    
    # Tabella dettagliata
    st.subheader("📋 Dettaglio Gap per Giorno e Fase")
    
    # Formattazione tabella con colori
    def color_gap(val):
        if val > 0:
            return 'background-color: #ffebee'  # Rosso chiaro per carenza
        elif val < 0:
            return 'background-color: #e8f5e8'  # Verde chiaro per surplus
        else:
            return 'background-color: #fff3e0'  # Arancione chiaro per equilibrio
    
    styled_df = df_gap.round(2).style.applymap(color_gap)
    st.dataframe(styled_df, use_container_width=True)
    
    # Analisi criticità
    st.subheader("⚠️ Analisi Criticità")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Giorni con maggiori criticità:**")
        gap_totali = df_gap.sum(axis=1).abs().sort_values(ascending=False)
        
        for giorno in gap_totali.head(3).index:
            gap_value = gap_totali[giorno]
            if gap_value > 0:
                st.error(f"• **{giorno}**: Gap totale {gap_value:.1f} teste")
    
    with col2:
        st.write("**Fasi più critiche:**")
        gap_per_fase = df_gap.abs().sum().sort_values(ascending=False)
        
        for fase, gap_value in gap_per_fase.items():
            if gap_value > 0:
                st.warning(f"• **{fase}**: Gap cumulativo {gap_value:.1f} teste")

def show_historical_report():
    st.header("📈 Report Storico")
    
    # Simulazione dati storici per dimostrare funzionalità
    st.subheader("📊 Analisi Tendenze Storiche")
    
    piano_attuale = st.session_state.data_manager.get_piano_settimanale()
    
    if not piano_attuale:
        st.warning("⚠️ Nessun dato storico disponibile. Inserire prima un piano settimanale.")
        return
    
    # Statistiche piano corrente
    df_piano = pd.DataFrame(piano_attuale).T
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Statistiche CLP per Categoria")
        
        stats = df_piano.describe()
        st.dataframe(stats, use_container_width=True)
    
    with col2:
        st.subheader("🎯 KPI Principali")
        
        totale_settimanale = df_piano.sum().sum()
        media_giornaliera = df_piano.sum(axis=1).mean()
        giorno_picco = df_piano.sum(axis=1).idxmax()
        carico_picco = df_piano.sum(axis=1).max()
        
        st.metric("Carico Totale Settimana", f"{totale_settimanale:,.0f}")
        st.metric("Media Giornaliera", f"{media_giornaliera:,.0f}")
        st.metric("Giorno di Picco", f"{giorno_picco}")
        st.metric("Carico Picco", f"{carico_picco:,.0f}")
    
    # Distribuzione carichi
    st.subheader("📈 Distribuzione Carichi")
    
    # Grafico distribuzione per categoria
    fig_dist = px.box(
        df_piano.melt(var_name='Categoria', value_name='CLP'),
        x='Categoria',
        y='CLP',
        title="Distribuzione CLP per Categoria"
    )
    st.plotly_chart(fig_dist, use_container_width=True)
    
    # Trend settimanale
    categorie_trend = st.session_state.data_manager.get_categorie()
    fig_trend = px.line(
        df_piano.reset_index(),
        x='index',
        y=categorie_trend,
        title="Trend Settimanale per Categoria",
        labels={'index': 'Giorno', 'value': 'CLP', 'variable': 'Categoria'}
    )
    st.plotly_chart(fig_trend, use_container_width=True)
    
    # Export dati
    st.subheader("📤 Export Dati")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📄 Scarica Report CSV"):
            csv = df_piano.to_csv(index=True)
            st.download_button(
                label="⬇️ Download CSV",
                data=csv,
                file_name=f"report_clp_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📊 Scarica Dati JSON"):
            json_data = json.dumps(piano_attuale, indent=2, ensure_ascii=False)
            st.download_button(
                label="⬇️ Download JSON",
                data=json_data,
                file_name=f"piano_settimanale_{datetime.now().strftime('%Y%m%d')}.json",
                mime="application/json"
            )

if __name__ == "__main__":
    main()
