# Dashboard Gestione Capacità/Carico Operativo

## Descrizione
Sistema completo per la gestione della capacità operativa e del carico di lavoro in ambito industriale. L'applicazione calcola il fabbisogno di personale, analizza i gap di capacità e fornisce strumenti di pianificazione operativa.

## Caratteristiche Principali
- 📊 **Dashboard Principale**: Inserimento e visualizzazione piano settimanale CLP
- 📈 **Analisi Gap**: Analisi avanzata dei gap capacità/fabbisogno
- 📋 **KPI e Reportistica**: Report storici e indicatori di performance
- ⚙️ **Configurazione Avanzata**: Gestione parametri sistema e simulazioni
- 🔧 **Categorie Dinamiche**: Supporto per categorie merceologiche configurabili
- 💾 **Backup & Restore**: Funzionalità complete di gestione dati

## Struttura del Progetto
```
dashboard-capacita-operativa/
├── app.py                      # Applicazione principale
├── pages/                      # Pagine dell'applicazione
│   ├── analisi_gap.py         # Analisi gap avanzata
│   ├── configurazione.py      # Configurazione sistema
│   └── kpi_reportistica.py    # KPI e reportistica
├── utils/                      # Moduli di utilità
│   ├── calculations.py        # Calcoli capacità e operatori
│   └── data_manager.py        # Gestione dati e persistenza
├── .streamlit/
│   └── config.toml            # Configurazione Streamlit
├── data/                      # Directory dati (creata automaticamente)
├── requirements.txt           # Dipendenze Python
└── README.md                  # Questa documentazione
```

## Installazione

1. **Clona o scarica il progetto**
2. **Installa le dipendenze:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Avvia l'applicazione:**
   ```bash
   streamlit run app.py
   ```

4. **Apri il browser** all'indirizzo: http://localhost:5000

## Calcoli Principali

### Formula CLP
**CLP = Q × V × P**
- Q = Quantità
- V = Volume  
- P = Peso

### Fasi Operative
1. **Scarico Mezzi**: Gestione arrivo merci
2. **Controllo**: Verifica qualità e conformità  
3. **Stoccaggio**: Posizionamento finale

### Calcoli Operatori
- **Ore Totali** = Operatori × Baie × Ore per turno
- **Teste Necessarie** = Ore totali necessarie / Ore per turno
- **Gap** = Teste necessarie - Teste disponibili

## Configurazione Default

### Capacità Produttive (CLP/h)
| Categoria    | Scarico Mezzi | Controllo | Stoccaggio |
|--------------|---------------|-----------|------------|
| Barre        | 280          | 150       | 1000       |
| Idrosanitari | 250          | 100       | 150        |
| Minuteria    | 200          | 130       | 200        |
| Container    | 200          | 120       | 800        |
| Serbatoi     | 150          | 80        | 600        |
| Pallet       | 300          | 180       | 1200       |

### Configurazione Operatori
- **Scarico Mezzi**: 1 operatore per baia, 8 ore per turno
- **Controllo**: 2 operatori per baia, 8 ore per turno
- **Stoccaggio**: 1 operatore per baia, 8 ore per turno
- **Numero Baie**: 5 per ogni fase

## Funzionalità Avanzate

### Simulazioni
- Scenari personalizzati
- Analisi what-if
- Ottimizzazione risorse
- Previsioni trend

### Export e Backup
- Backup completo sistema
- Export CSV/JSON
- Import dati storici
- Reset sistema

### Categorie Dinamiche
- Aggiunta/rimozione categorie
- Configurazione automatica capacità
- Layout responsivo

## Supporto
Per assistenza o domande sull'utilizzo dell'applicazione, consultare la documentazione integrata nell'interfaccia utente.

---
*Dashboard Gestione Capacità/Carico Operativo - Versione 2025*