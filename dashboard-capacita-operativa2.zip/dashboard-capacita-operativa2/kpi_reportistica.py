"""
Pagina per report e analisi storiche avanzate
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from datetime import datetime, timedelta
import json
import sys
import os

# Aggiungi il path per importare i moduli utils
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.data_manager import DataManager
from utils.calculations import CalcolatoreCapacita

def show_advanced_historical_reports():
    """Mostra report storici avanzati"""
    
    # Inizializzazione session state
    if 'data_manager' not in st.session_state:
        st.session_state.data_manager = DataManager()
    if 'calcolatore' not in st.session_state:
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    st.header("📈 Report Storici Avanzati")
    
    tab1, tab2, tab3, tab4 = st.tabs([
        "Dashboard KPI",
        "Analisi Performance", 
        "Benchmarking",
        "Export Avanzato"
    ])
    
    with tab1:
        show_kpi_dashboard()
    
    with tab2:
        show_performance_analysis()
    
    with tab3:
        show_benchmarking_analysis()
    
    with tab4:
        show_advanced_export()

def show_kpi_dashboard():
    """Dashboard KPI principali"""
    
    st.subheader("📊 Dashboard KPI Operativi")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    
    if not all([piano, capacita, config_operatori]):
        st.warning("⚠️ Dati insufficienti per generare KPI")
        return
    
    # Calcolo KPI principali
    kpi_data = calculate_main_kpis(piano, capacita, config_operatori)
    
    # Sezione KPI principali
    st.write("**🎯 KPI Principali:**")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Carico Totale Settimana",
            f"{kpi_data['carico_totale']:,.0f}",
            f"{kpi_data['variazione_carico']:+.1f}%"
        )
    
    with col2:
        st.metric(
            "Utilizzo Medio Capacità",
            f"{kpi_data['utilizzo_medio']:.1f}%",
            f"{kpi_data['delta_utilizzo']:+.1f}%"
        )
    
    with col3:
        st.metric(
            "Gap Operatori Medio",
            f"{kpi_data['gap_medio']:+.1f}",
            "teste" if abs(kpi_data['gap_medio']) != 1 else "testa"
        )
    
    with col4:
        st.metric(
            "Efficienza Sistema",
            f"{kpi_data['efficienza']:.1f}%",
            f"{kpi_data['trend_efficienza']:+.1f}%"
        )
    
    # Gauge charts per KPI critici
    st.write("**🎛️ Indicatori Stato Sistema:**")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        fig_utilizzo = create_gauge_chart(
            kpi_data['utilizzo_medio'], 
            "Utilizzo Capacità",
            0, 150, 
            [80, 100]
        )
        st.plotly_chart(fig_utilizzo, use_container_width=True)
    
    with col2:
        # Gap normalizzato per gauge (0-100, dove 50 è equilibrio)
        gap_normalized = max(0, min(100, 50 - kpi_data['gap_medio'] * 10))
        fig_gap = create_gauge_chart(
            gap_normalized,
            "Equilibrio Risorse", 
            0, 100,
            [30, 70]
        )
        st.plotly_chart(fig_gap, use_container_width=True)
    
    with col3:
        fig_efficienza = create_gauge_chart(
            kpi_data['efficienza'],
            "Efficienza Sistema",
            0, 100,
            [70, 85]
        )
        st.plotly_chart(fig_efficienza, use_container_width=True)
    
    # Distribuzione carico per categoria
    st.write("**📊 Distribuzione Carico per Categoria:**")
    
    df_piano = pd.DataFrame(piano).T
    totali_categoria = df_piano.sum()
    
    fig_pie = px.pie(
        values=totali_categoria.values,
        names=totali_categoria.index,
        title="Distribuzione CLP Settimanale per Categoria"
    )
    
    st.plotly_chart(fig_pie, use_container_width=True)
    
    # Trend giornaliero
    st.write("**📈 Trend Giornaliero:**")
    
    df_trend_giorni = df_piano.copy()
    df_trend_giorni['Totale'] = df_trend_giorni.sum(axis=1)
    
    fig_trend = px.line(
        df_trend_giorni.reset_index().melt(
            id_vars='index', 
            var_name='Categoria', 
            value_name='CLP'
        ),
        x='index',
        y='CLP',
        color='Categoria',
        title="Trend CLP per Giorno e Categoria",
        markers=True,
        labels={'index': 'Giorno'}
    )
    
    st.plotly_chart(fig_trend, use_container_width=True)

def show_performance_analysis():
    """Analisi delle performance operative"""
    
    st.subheader("⚡ Analisi Performance Operative")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    categorie = st.session_state.data_manager.get_categorie()
    
    if not all([piano, capacita, config_operatori]):
        st.warning("⚠️ Configurare tutti i parametri per l'analisi")
        return
    
    # Selezione tipo di vista
    st.write("**📊 Seleziona Vista Analisi:**")
    
    col_vista1, col_vista2 = st.columns([1, 2])
    
    with col_vista1:
        tipo_vista = st.selectbox(
            "Tipo di Vista",
            ["Vista Settimanale", "Vista Giornaliera"],
            help="Scegli se analizzare l'intera settimana o un singolo giorno"
        )
    
    with col_vista2:
        giorno_selezionato = None
        if tipo_vista == "Vista Giornaliera":
            giorni_disponibili = list(piano.keys())
            if giorni_disponibili:
                giorno_selezionato = st.selectbox(
                    "Seleziona Giorno",
                    giorni_disponibili,
                    help="Scegli il giorno specifico da analizzare"
                )
            else:
                st.warning("⚠️ Nessun dato disponibile nel piano settimanale")
                return
        else:
            # Placeholder per mantenere il layout quando non serve il selettore
            st.empty()
    
    st.divider()
    
    # Analisi performance per fase
    if tipo_vista == "Vista Settimanale":
        st.write("**🎯 Performance per Fase Operativa - Vista Settimanale:**")
    else:
        st.write(f"**🎯 Performance per Fase Operativa - {giorno_selezionato}:**")
    
    performance_data = []
    
    # Filtra i giorni in base alla vista selezionata
    if tipo_vista == "Vista Giornaliera" and giorno_selezionato:
        giorni_da_analizzare = {giorno_selezionato: piano[giorno_selezionato]}
    else:
        giorni_da_analizzare = piano
    
    for giorno, dati_giorno in giorni_da_analizzare.items():
        risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
            dati_giorno, capacita, config_operatori, categorie
        )
        
        utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
            dati_giorno, capacita, config_operatori
        )
        
        for fase in ['Scarico Mezzi', 'Controllo', 'Stoccaggio']:
            performance_data.append({
                'Giorno': giorno,
                'Fase': fase,
                'Fabbisogno_Ore': risultati['fabbisogno_ore'][fase],
                'Fabbisogno_Teste': risultati['fabbisogno_teste'][fase],
                'Gap_Teste': risultati['gap_teste'][fase],
                'Utilizzo_%': utilizzi[fase],
                'Operatori_Disponibili': risultati['operatori_disponibili'][fase]
            })
    
    df_performance = pd.DataFrame(performance_data)
    
    # Calcolo efficienza (utilizzo ottimale vs gap)
    df_performance['Efficienza'] = df_performance.apply(
        lambda row: calculate_efficiency_score(row['Utilizzo_%'], row['Gap_Teste']), 
        axis=1
    )
    
    # Definisci ordini corretti per giorni e fasi
    ordine_giorni = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica']
    ordine_fasi = ['Scarico Mezzi', 'Controllo', 'Stoccaggio']
    
    if tipo_vista == "Vista Settimanale":
        # Vista settimanale - Heatmaps
        st.write("**🔥 Matrice Performance Settimanale:**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Heatmap utilizzo
            pivot_utilizzo = df_performance.pivot(index='Giorno', columns='Fase', values='Utilizzo_%')
            # Riordina righe e colonne
            pivot_utilizzo = pivot_utilizzo.reindex(index=ordine_giorni, columns=ordine_fasi)
            
            fig_utilizzo = px.imshow(
                pivot_utilizzo,
                title="Heatmap Utilizzo Capacità (%)",
                color_continuous_scale='RdYlGn',
                labels={'color': 'Utilizzo %'},
                aspect='auto'
            )
            # Inverte l'asse Y per mostrare Lunedì in alto
            fig_utilizzo.update_yaxes(autorange='reversed')
            
            st.plotly_chart(fig_utilizzo, use_container_width=True)
        
        with col2:
            # Heatmap gap
            pivot_gap = df_performance.pivot(index='Giorno', columns='Fase', values='Gap_Teste')
            # Riordina righe e colonne
            pivot_gap = pivot_gap.reindex(index=ordine_giorni, columns=ordine_fasi)
            
            fig_gap = px.imshow(
                pivot_gap,
                title="Heatmap Gap Operatori",
                color_continuous_scale='RdYlGn_r',
                labels={'color': 'Gap Teste'},
                aspect='auto'
            )
            # Inverte l'asse Y per mostrare Lunedì in alto
            fig_gap.update_yaxes(autorange='reversed')
            
            st.plotly_chart(fig_gap, use_container_width=True)
        
        # Box plot per efficienza settimanale
        st.write("**📊 Analisi Efficienza per Fase:**")
        
        fig_efficienza = px.box(
            df_performance,
            x='Fase',
            y='Efficienza',
            title="Distribuzione Efficienza per Fase",
            category_orders={'Fase': ordine_fasi}
        )
        
        st.plotly_chart(fig_efficienza, use_container_width=True)
        
    else:
        # Vista giornaliera - Grafici a barre
        st.write(f"**📊 Performance Dettagliata - {giorno_selezionato}:**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Grafico a barre utilizzo per fase
            fig_util_giorno = px.bar(
                df_performance,
                x='Fase',
                y='Utilizzo_%',
                title=f"Utilizzo Capacità per Fase - {giorno_selezionato}",
                color='Utilizzo_%',
                color_continuous_scale='RdYlGn',
                labels={'Utilizzo_%': 'Utilizzo %'},
                category_orders={'Fase': ordine_fasi}
            )
            fig_util_giorno.update_layout(showlegend=False)
            
            st.plotly_chart(fig_util_giorno, use_container_width=True)
        
        with col2:
            # Grafico a barre gap per fase
            fig_gap_giorno = px.bar(
                df_performance,
                x='Fase',
                y='Gap_Teste',
                title=f"Gap Operatori per Fase - {giorno_selezionato}",
                color='Gap_Teste',
                color_continuous_scale='RdYlGn_r',
                labels={'Gap_Teste': 'Gap Operatori'},
                category_orders={'Fase': ordine_fasi}
            )
            fig_gap_giorno.update_layout(showlegend=False)
            
            st.plotly_chart(fig_gap_giorno, use_container_width=True)
        
        # Grafico efficienza per fase giornaliera
        st.write("**📊 Efficienza per Fase:**")
        
        fig_eff_giorno = px.bar(
            df_performance,
            x='Fase',
            y='Efficienza',
            title=f"Efficienza per Fase - {giorno_selezionato}",
            color='Efficienza',
            color_continuous_scale='RdYlGn',
            labels={'Efficienza': 'Punteggio Efficienza'}
        )
        fig_eff_giorno.update_layout(showlegend=False)
        
        st.plotly_chart(fig_eff_giorno, use_container_width=True)
    
    # Tabella performance dettagliata
    st.write("**📋 Performance Dettagliata:**")
    
    # Aggiungi colori condizionali
    def highlight_performance(row):
        styles = []
        
        for col in row.index:
            if 'Gap_Teste' in col:
                if row[col] > 1:
                    styles.append('background-color: #ffebee')  # Rosso per gap elevato
                elif row[col] < -0.5:
                    styles.append('background-color: #e8f5e8')  # Verde per surplus
                else:
                    styles.append('')
            elif 'Utilizzo_%' in col:
                if row[col] > 100:
                    styles.append('background-color: #ffebee')  # Rosso per sovrautilizzo
                elif row[col] < 50:
                    styles.append('background-color: #fff3e0')  # Arancione per sottoutilizzo
                else:
                    styles.append('')
            elif 'Efficienza' in col:
                if row[col] > 80:
                    styles.append('background-color: #e8f5e8')  # Verde per alta efficienza
                elif row[col] < 60:
                    styles.append('background-color: #ffebee')  # Rosso per bassa efficienza
                else:
                    styles.append('')
            else:
                styles.append('')
        
        return styles
    
    styled_df = df_performance.round(2).style.apply(highlight_performance, axis=1)
    st.dataframe(styled_df, use_container_width=True)

def show_benchmarking_analysis():
    """Analisi di benchmarking e confronti"""
    
    st.subheader("📊 Benchmarking e Confronti")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    capacita = st.session_state.data_manager.get_capacita_produttive()
    
    if not all([piano, capacita]):
        st.warning("⚠️ Dati insufficienti per benchmarking")
        return
    
    # Benchmark contro standard industriali (simulati)
    st.write("**🏆 Benchmark Standard Industriali:**")
    
    # Standard simulati
    standard_industriali = {
        'Utilizzo_Capacità_Target': 85,
        'Gap_Massimo_Accettabile': 1.0,
        'Efficienza_Minima': 75,
        'CLP_per_Operatore_Giorno': 800
    }
    
    # Calcolo metriche attuali
    df_piano = pd.DataFrame(piano).T
    carico_totale = df_piano.sum().sum()
    
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    operatori_totali = (
        config_operatori.get('scarico_per_baia', 1) +
        config_operatori.get('controllo_per_baia', 2) + 
        config_operatori.get('stoccaggio_per_baia', 1)
    ) * 5  # 5 baie
    
    clp_per_operatore = carico_totale / operatori_totali / len(piano)
    
    # Calcolo utilizzo medio
    utilizzi_giornalieri = []
    for giorno, dati_giorno in piano.items():
        utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
            dati_giorno, capacita, config_operatori
        )
        utilizzi_giornalieri.append(sum(utilizzi.values()) / len(utilizzi))
    
    utilizzo_medio_attuale = sum(utilizzi_giornalieri) / len(utilizzi_giornalieri)
    
    # Visualizzazione benchmark
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        delta_utilizzo = utilizzo_medio_attuale - standard_industriali['Utilizzo_Capacità_Target']
        color_utilizzo = "normal" if abs(delta_utilizzo) <= 5 else ("inverse" if delta_utilizzo < 0 else "off")
        
        st.metric(
            "Utilizzo Capacità",
            f"{utilizzo_medio_attuale:.1f}%",
            f"{delta_utilizzo:+.1f}% vs target",
            delta_color=color_utilizzo
        )
    
    with col2:
        # Gap medio simulato
        gap_medio_simulato = 0.5  # Valore esempio
        delta_gap = gap_medio_simulato - standard_industriali['Gap_Massimo_Accettabile']
        color_gap = "normal" if delta_gap <= 0 else "inverse"
        
        st.metric(
            "Gap Medio",
            f"{gap_medio_simulato:.1f}",
            f"{delta_gap:+.1f} vs max",
            delta_color=color_gap
        )
    
    with col3:
        efficienza_simulata = 78  # Valore esempio
        delta_eff = efficienza_simulata - standard_industriali['Efficienza_Minima']
        color_eff = "normal" if delta_eff >= 0 else "inverse"
        
        st.metric(
            "Efficienza Sistema",
            f"{efficienza_simulata}%",
            f"{delta_eff:+.0f}% vs min",
            delta_color=color_eff
        )
    
    with col4:
        delta_clp = clp_per_operatore - standard_industriali['CLP_per_Operatore_Giorno']
        color_clp = "normal" if abs(delta_clp) <= 50 else ("off" if delta_clp > 0 else "inverse")
        
        st.metric(
            "CLP per Operatore",
            f"{clp_per_operatore:.0f}",
            f"{delta_clp:+.0f} vs target",
            delta_color=color_clp
        )
    
    # Radar chart per confronto multi-dimensionale
    st.write("**🎯 Profilo Performance vs Standard:**")
    
    metriche_radar = {
        'Utilizzo Capacità': min(100, (utilizzo_medio_attuale / 85) * 100),
        'Controllo Gap': min(100, (1 / max(0.1, gap_medio_simulato)) * 50),
        'Efficienza': efficienza_simulata,
        'Produttività': min(100, (clp_per_operatore / 800) * 100),
        'Bilanciamento': 85  # Valore simulato
    }
    
    target_radar = {
        'Utilizzo Capacità': 100,
        'Controllo Gap': 100,
        'Efficienza': 100, 
        'Produttività': 100,
        'Bilanciamento': 100
    }
    
    fig_radar = go.Figure()
    
    fig_radar.add_trace(go.Scatterpolar(
        r=list(metriche_radar.values()),
        theta=list(metriche_radar.keys()),
        fill='toself',
        name='Attuale',
        line_color='blue'
    ))
    
    fig_radar.add_trace(go.Scatterpolar(
        r=list(target_radar.values()),
        theta=list(target_radar.keys()),
        fill='toself',
        name='Target',
        line_color='red',
        opacity=0.3
    ))
    
    fig_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )
        ),
        showlegend=True,
        title="Confronto Performance vs Target"
    )
    
    st.plotly_chart(fig_radar, use_container_width=True)
    
    # Analisi gap vs benchmark
    st.write("**📈 Analisi Gap vs Benchmark:**")
    
    gap_analysis = {
        'Metrica': ['Utilizzo Capacità', 'Controllo Gap', 'Efficienza', 'Produttività'],
        'Attuale': [utilizzo_medio_attuale, gap_medio_simulato, efficienza_simulata, clp_per_operatore],
        'Target': [85, 1.0, 75, 800],
        'Gap': [
            utilizzo_medio_attuale - 85,
            gap_medio_simulato - 1.0,
            efficienza_simulata - 75,
            clp_per_operatore - 800
        ]
    }
    
    df_gap_analysis = pd.DataFrame(gap_analysis)
    
    fig_gap_bench = px.bar(
        df_gap_analysis,
        x='Metrica',
        y='Gap',
        title="Gap vs Benchmark (Valori Positivi = Sopra Target)",
        color='Gap',
        color_continuous_scale='RdYlGn'
    )
    
    fig_gap_bench.add_hline(y=0, line_dash="dash", line_color="black")
    st.plotly_chart(fig_gap_bench, use_container_width=True)

def show_advanced_export():
    """Export avanzato con formattazione"""
    
    st.subheader("📤 Export Avanzato Report")
    
    piano = st.session_state.data_manager.get_piano_settimanale()
    
    if not piano:
        st.warning("⚠️ Nessun dato disponibile per export")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**📊 Formato Export:**")
        
        formato_export = st.selectbox(
            "Seleziona formato",
            ["CSV", "Excel (XLSX)", "JSON", "PDF Report"]
        )
        
        include_grafici = st.checkbox("Includi grafici", value=True)
        include_calcoli = st.checkbox("Includi calcoli dettagliati", value=True)
        include_kpi = st.checkbox("Includi KPI", value=True)
    
    with col2:
        st.write("**🎯 Personalizzazione:**")
        
        periodo_export = st.selectbox(
            "Periodo",
            ["Settimana corrente", "Ultimo mese", "Trimestre", "Anno"]
        )
        
        dettaglio_export = st.selectbox(
            "Livello dettaglio",
            ["Sommario", "Dettagliato", "Completo"]
        )
        
        lingua_export = st.selectbox(
            "Lingua",
            ["Italiano", "English"]
        )
    
    # Generazione report
    if st.button("📋 Genera Report"):
        
        with st.spinner("Generazione report in corso..."):
            # Simula generazione report
            import time
            time.sleep(2)
            
            report_data = generate_export_data(
                piano, formato_export, include_grafici, include_calcoli, include_kpi
            )
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"report_capacita_carico_{timestamp}"
            
            if formato_export == "CSV":
                st.download_button(
                    label="⬇️ Scarica Report CSV",
                    data=report_data,
                    file_name=f"{filename}.csv",
                    mime="text/csv"
                )
            
            elif formato_export == "JSON":
                st.download_button(
                    label="⬇️ Scarica Report JSON",
                    data=report_data,
                    file_name=f"{filename}.json",
                    mime="application/json"
                )
            
            elif formato_export == "Excel (XLSX)":
                # Per Excel, mostriamo anteprima
                st.success("✅ Report Excel pronto!")
                st.info("📊 Funzionalità Excel completa disponibile nella versione estesa")
                
                # Mostra anteprima dati
                st.write("**Anteprima dati:**")
                df_preview = pd.DataFrame(piano).T
                st.dataframe(df_preview)
            
            elif formato_export == "PDF Report":
                st.success("✅ Report PDF generato!")
                st.info("📄 Funzionalità PDF completa disponibile nella versione estesa")
        
        st.success("✅ Report generato con successo!")
    
    # Programmazione export automatici
    st.write("---")
    st.write("**⏰ Export Automatici:**")
    
    col1, col2 = st.columns(2)
    
    with col1:
        abilita_auto = st.checkbox("Abilita export automatici")
        
        if abilita_auto:
            frequenza = st.selectbox(
                "Frequenza",
                ["Giornaliera", "Settimanale", "Mensile"]
            )
            
            orario = st.time_input("Orario export", value=datetime.now().time())
    
    with col2:
        if abilita_auto:
            email_destinatari = st.text_area(
                "Email destinatari (uno per riga)",
                placeholder="manager@azienda.it\noperations@azienda.it"
            )
            
            if st.button("💾 Salva Programmazione"):
                st.success("✅ Export automatici configurati!")

# Funzioni helper

def calculate_main_kpis(piano, capacita, config_operatori):
    """Calcola KPI principali basati su dati reali"""
    
    if 'calcolatore' not in st.session_state:
        from utils.calculations import CalcolatoreCapacita
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    categorie = st.session_state.data_manager.get_categorie()
    
    df_piano = pd.DataFrame(piano).T
    carico_totale = df_piano.sum().sum()
    
    # Calcoli reali basati sui dati
    total_utilizzo = 0
    total_gap = 0
    total_efficienza = 0
    num_fasi_attive = 0
    giorni_con_carico = 0
    
    for giorno, dati_giorno in piano.items():
        # Verifica se il giorno ha carico di lavoro
        clp_giorno = sum(dati_giorno.get(cat, 0) for cat in categorie)
        
        if clp_giorno > 0:
            giorni_con_carico += 1
            
            # Calcola fabbisogno operatori
            risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_operatori, categorie
            )
            
            # Calcola utilizzo capacità
            utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
                dati_giorno, capacita, config_operatori, categorie
            )
            
            # Accumula metriche per ogni fase
            for fase in ['Scarico Mezzi', 'Controllo', 'Stoccaggio']:
                total_utilizzo += utilizzi[fase]
                total_gap += risultati['gap_teste'][fase]
                total_efficienza += calculate_efficiency_score(utilizzi[fase], risultati['gap_teste'][fase])
                num_fasi_attive += 1
    
    # Calcola valori medi (se ci sono giorni attivi)
    if num_fasi_attive > 0:
        utilizzo_medio = total_utilizzo / num_fasi_attive
        gap_medio = total_gap / num_fasi_attive
        efficienza = total_efficienza / num_fasi_attive
    else:
        # Piano vuoto - nessun carico di lavoro
        utilizzo_medio = 0
        # Gap negativo = operatori disponibili senza lavoro
        # Calcola usando le chiavi corrette per ogni fase
        fase_keys = {
            'Scarico Mezzi': 'scarico',
            'Controllo': 'controllo',
            'Stoccaggio': 'stoccaggio'
        }
        
        total_operatori_disponibili = 0
        for fase, fase_key in fase_keys.items():
            operatori_per_baia = config_operatori.get(f'{fase_key}_per_baia', 1)
            numero_baie = config_operatori.get(f'baie_{fase_key}', 5)
            total_operatori_disponibili += (operatori_per_baia * numero_baie)
        
        gap_medio = -total_operatori_disponibili / 3  # Media delle 3 fasi
        efficienza = 0
    
    # Calcola variazioni (confronto con storico se disponibile)
    storico_data = st.session_state.data_manager.get_historical_data()
    variazione_carico = 0
    delta_utilizzo = 0
    trend_efficienza = 0
    
    if storico_data and len(storico_data) > 1:
        # Prendi l'ultima settimana salvata nello storico
        try:
            settimane_storiche = [entry for entry in storico_data if entry.get('type') == 'piano_settimanale']
            if len(settimane_storiche) >= 2:
                settimana_precedente = settimane_storiche[-2]['data']
                df_precedente = pd.DataFrame(settimana_precedente).T
                carico_precedente = df_precedente.sum().sum()
                
                if carico_precedente > 0:
                    variazione_carico = ((carico_totale - carico_precedente) / carico_precedente) * 100
        except:
            pass
    
    return {
        'carico_totale': carico_totale,
        'variazione_carico': variazione_carico,
        'utilizzo_medio': utilizzo_medio,
        'delta_utilizzo': delta_utilizzo,
        'gap_medio': gap_medio,
        'efficienza': efficienza,
        'trend_efficienza': trend_efficienza
    }

def create_gauge_chart(value, title, min_val, max_val, thresholds):
    """Crea gauge chart"""
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title},
        gauge={
            'axis': {'range': [min_val, max_val]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [min_val, thresholds[0]], 'color': "lightgray"},
                {'range': [thresholds[0], thresholds[1]], 'color': "yellow"},
                {'range': [thresholds[1], max_val], 'color': "lightgreen"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': max_val * 0.9
            }
        }
    ))
    
    fig.update_layout(height=300)
    return fig

def calculate_efficiency_score(utilizzo, gap):
    """Calcola punteggio efficienza"""
    
    # Efficienza basata su utilizzo ottimale (80-90%) e gap minimo
    utilizzo_score = 100 - abs(utilizzo - 85)  # 85% utilizzo ottimale
    gap_score = max(0, 100 - abs(gap) * 20)  # Penalità per gap
    
    return (utilizzo_score + gap_score) / 2

def generate_export_data(piano, formato, include_grafici, include_calcoli, include_kpi):
    """Genera dati per export con analisi completa"""
    
    if formato == "CSV":
        return generate_comprehensive_csv_report(piano, include_calcoli, include_kpi)
    
    elif formato == "JSON":
        export_dict = {
            "timestamp": datetime.now().isoformat(),
            "piano_settimanale": piano,
            "metadata": {
                "include_grafici": include_grafici,
                "include_calcoli": include_calcoli,
                "include_kpi": include_kpi
            }
        }
        if include_calcoli:
            export_dict["analisi_completa"] = generate_complete_analysis_data(piano)
            
        return json.dumps(export_dict, indent=2, ensure_ascii=False)
    
    return ""

def generate_comprehensive_csv_report(piano, include_calcoli, include_kpi):
    """Genera report CSV completo con tutte le analisi"""
    
    # Inizializza calcolatore e ottieni configurazioni
    if 'calcolatore' not in st.session_state:
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    categorie = st.session_state.data_manager.get_categorie()
    
    # Inizializza liste per dati completi
    all_data = []
    
    # Sezione 1: Piano Base
    all_data.append(["=== PIANO SETTIMANALE CLP (Base) ==="])
    all_data.append([""])
    
    # Header del piano base
    giorni = list(piano.keys())
    categorie = st.session_state.data_manager.get_categorie()
    
    header_piano = ["Giorno"] + categorie
    all_data.append(header_piano)
    
    for giorno in giorni:
        row = [giorno]
        for categoria in categorie:
            row.append(piano.get(giorno, {}).get(categoria, 0))
        all_data.append(row)
    
    all_data.append([""])
    
    if include_calcoli:
        # Sezione 2: Analisi Fabbisogno Operatori
        all_data.append(["=== ANALISI FABBISOGNO OPERATORI ==="])
        all_data.append([""])
        
        # Header fabbisogno
        fasi = ["Scarico Mezzi", "Controllo", "Stoccaggio"]
        header_fabbisogno = ["Giorno", "Fase", "Ore_Necessarie", "Teste_Necessarie", "Operatori_Disponibili", "Gap_Teste"]
        all_data.append(header_fabbisogno)
        
        for giorno, dati_giorno in piano.items():
            risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_operatori, categorie
            )
            
            for fase in fasi:
                row = [
                    giorno,
                    fase,
                    round(risultati['fabbisogno_ore'][fase], 2),
                    round(risultati['fabbisogno_teste'][fase], 2),
                    risultati['operatori_disponibili'][fase],
                    round(risultati['gap_teste'][fase], 2)
                ]
                all_data.append(row)
        
        all_data.append([""])
        
        # Sezione 3: Analisi Utilizzo Capacità
        all_data.append(["=== ANALISI UTILIZZO CAPACITA ==="])
        all_data.append([""])
        
        header_utilizzo = ["Giorno", "Fase", "Utilizzo_%"]
        all_data.append(header_utilizzo)
        
        for giorno, dati_giorno in piano.items():
            utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
                dati_giorno, capacita, config_operatori
            )
            
            for fase in fasi:
                row = [
                    giorno,
                    fase,
                    round(utilizzi[fase], 2)
                ]
                all_data.append(row)
        
        all_data.append([""])
        
        # Sezione 4: Analisi Efficienza
        all_data.append(["=== ANALISI EFFICIENZA ==="])
        all_data.append([""])
        
        header_efficienza = ["Giorno", "Fase", "Punteggio_Efficienza"]
        all_data.append(header_efficienza)
        
        for giorno, dati_giorno in piano.items():
            risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_operatori, categorie
            )
            utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
                dati_giorno, capacita, config_operatori
            )
            
            for fase in fasi:
                efficienza = calculate_efficiency_score(utilizzi[fase], risultati['gap_teste'][fase])
                row = [
                    giorno,
                    fase,
                    round(efficienza, 2)
                ]
                all_data.append(row)
        
        all_data.append([""])
    
    if include_kpi:
        # Sezione 5: KPI Settimanali
        all_data.append(["=== KPI SETTIMANALI ==="])
        all_data.append([""])
        
        # Calcola KPI aggregati
        kpi_data = calculate_weekly_kpis(piano, capacita, config_operatori)
        
        all_data.append(["Metrica", "Valore", "Unità"])
        for metrica, valore in kpi_data.items():
            if isinstance(valore, dict):
                for sub_key, sub_value in valore.items():
                    all_data.append([f"{metrica}_{sub_key}", round(sub_value, 2), "varie"])
            else:
                all_data.append([metrica, round(valore, 2), "varie"])
        
        all_data.append([""])
        
        # Sezione 6: Raccomandazioni
        all_data.append(["=== RACCOMANDAZIONI OTTIMIZZAZIONE ==="])
        all_data.append([""])
        
        suggerimenti = st.session_state.calcolatore.ottimizza_distribuzione_operatori(piano, capacita)
        
        all_data.append(["Fase", "Carico_Medio_Ore", "Percentuale_Carico", "Operatori_Suggeriti"])
        for fase, dati in suggerimenti.items():
            row = [
                fase,
                dati['carico_medio_ore'],
                dati['percentuale_carico'],
                dati['operatori_suggeriti']
            ]
            all_data.append(row)
    
    # Converti in DataFrame e poi CSV
    max_cols = max(len(row) for row in all_data)
    normalized_data = []
    for row in all_data:
        # Riempie con celle vuote per avere tutte le righe della stessa lunghezza
        while len(row) < max_cols:
            row.append("")
        normalized_data.append(row)
    
    df_export = pd.DataFrame(normalized_data)
    return df_export.to_csv(index=False, header=False)

def calculate_weekly_kpis(piano, capacita, config_operatori):
    """Calcola KPI settimanali aggregati"""
    
    if 'calcolatore' not in st.session_state:
        from utils.calculations import CalcolatoreCapacita
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    categorie = st.session_state.data_manager.get_categorie()
    
    total_clp = 0
    total_ore_necessarie = 0
    total_gap_positivo = 0
    total_gap_negativo = 0
    utilizzo_medio = 0
    efficienza_media = 0
    giorni_attivi = 0
    
    for giorno, dati_giorno in piano.items():
        # Controlla se il giorno ha dati attivi
        clp_giorno = sum(dati_giorno.get(cat, 0) for cat in categorie)
        if clp_giorno > 0:
            giorni_attivi += 1
            total_clp += clp_giorno
            
            # Calcoli per questo giorno
            risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
                dati_giorno, capacita, config_operatori, categorie
            )
            utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
                dati_giorno, capacita, config_operatori
            )
            
            # Accumula metriche
            for fase in ["Scarico Mezzi", "Controllo", "Stoccaggio"]:
                total_ore_necessarie += risultati['fabbisogno_ore'][fase]
                gap = risultati['gap_teste'][fase]
                if gap > 0:
                    total_gap_positivo += gap
                else:
                    total_gap_negativo += abs(gap)
                
                utilizzo_medio += utilizzi[fase]
                efficienza_media += calculate_efficiency_score(utilizzi[fase], gap)
    
    # Calcola medie
    num_fase_giorni = giorni_attivi * 3 if giorni_attivi > 0 else 1  # 3 fasi per giorno
    
    return {
        'CLP_Totale_Settimana': total_clp,
        'Ore_Necessarie_Totali': total_ore_necessarie,
        'Gap_Carenza_Operatori': total_gap_positivo,
        'Gap_Surplus_Operatori': total_gap_negativo,
        'Utilizzo_Medio_Percent': utilizzo_medio / num_fase_giorni if num_fase_giorni > 0 else 0,
        'Efficienza_Media': efficienza_media / num_fase_giorni if num_fase_giorni > 0 else 0,
        'Giorni_Operativi': giorni_attivi
    }

def generate_complete_analysis_data(piano):
    """Genera dati completi di analisi per export JSON"""
    
    if 'calcolatore' not in st.session_state:
        from utils.calculations import CalcolatoreCapacita
        st.session_state.calcolatore = CalcolatoreCapacita()
    
    capacita = st.session_state.data_manager.get_capacita_produttive()
    config_operatori = st.session_state.data_manager.get_configurazione_operatori()
    categorie = st.session_state.data_manager.get_categorie()
    
    analisi_completa = {
        'fabbisogno_dettagliato': {},
        'utilizzo_capacita': {},
        'efficienza': {},
        'kpi_settimanali': calculate_weekly_kpis(piano, capacita, config_operatori),
        'raccomandazioni': st.session_state.calcolatore.ottimizza_distribuzione_operatori(piano, capacita)
    }
    
    for giorno, dati_giorno in piano.items():
        # Fabbisogno
        risultati = st.session_state.calcolatore.calcola_fabbisogno_giornaliero(
            dati_giorno, capacita, config_operatori, categorie
        )
        analisi_completa['fabbisogno_dettagliato'][giorno] = risultati
        
        # Utilizzo
        utilizzi = st.session_state.calcolatore.calcola_utilizzo_capacita(
            dati_giorno, capacita, config_operatori
        )
        analisi_completa['utilizzo_capacita'][giorno] = utilizzi
        
        # Efficienza
        efficienza_giorno = {}
        for fase in ["Scarico Mezzi", "Controllo", "Stoccaggio"]:
            efficienza_giorno[fase] = calculate_efficiency_score(
                utilizzi[fase], risultati['gap_teste'][fase]
            )
        analisi_completa['efficienza'][giorno] = efficienza_giorno
    
    return analisi_completa

# Chiamata diretta per esecuzione come pagina Streamlit
show_advanced_historical_reports()
